SMAB WEBSITE PACKAGE
====================

Files:
- index.html
- assets/smab-logo.png

Preview:
Open index.html in a browser.

Free publishing:
1. Create a GitHub repository (with help from a parent/guardian if needed).
2. Upload index.html and the assets folder, keeping the folder structure.
3. In repository Settings > Pages, choose Deploy from a branch.
4. Select the main branch and root folder, then Save.
5. GitHub Pages will provide the public website URL after deployment.

Notes:
- The contact form opens an email draft; it does not send or store submissions.
- The site is a project/early-stage initiative, not a claim of company registration.
- Replace the blank mailto recipient in index.html with an official contact email before launch.
